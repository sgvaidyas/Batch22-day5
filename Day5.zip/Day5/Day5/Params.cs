﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Params
    {
        static void myfun(params int[] a)
        {
            foreach(int x in a)
                Console.WriteLine(x);
        }
        static void fun1(params object[] n)
        {
            for(int i=0;i<n.Length;i++)
                Console.WriteLine(n[i]);
        }

        static void Main(string[] args)
        {
            myfun(2,5,6,8,6,11);
            fun1("Apple",44,55.6,'A');
        }
    }
}
