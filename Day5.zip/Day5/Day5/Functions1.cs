﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Functions1
    {
        public void add(int a,int b)
        {
            int sum = a + b;
            Console.WriteLine("Sum = "+sum);
        }
        public int fun(int a,out int res)
        {
            res =a + 5;
            return a * 5;
        }
        static void Main(string[] args)
        {
            Functions1 ob = new Functions1();
            ob.add(22, 33);
            int res;
            int x = ob.fun(5, out res);
            Console.WriteLine("X = " +x);
            Console.WriteLine("RES = " + res);
        }
    }
}
