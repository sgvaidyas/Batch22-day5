﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Program
    {
        static void input(int[,] a)
        {
            int r, c;
            r = a.GetLength(0);
            c = a.GetLength(1);
            Console.WriteLine("Enter array elements= ");
            for(int i=0;i<r;i++)
            {
                for(int j=0;j<c;j++)
                {
                    a[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        static void output(int[,] a)
        {
            int r, c;
            r = a.GetLength(0);
            c = a.GetLength(1);
            Console.WriteLine("Array elements= ");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    Console.Write( a[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }




        static void Main(string[] args)
        {
            int r1, r2, c1, c2;
            Console.WriteLine("Enter the row and col of A matrix");
            r1 = int.Parse(Console.ReadLine());
            c1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the row and col of B matrix");
            r2 = int.Parse(Console.ReadLine());
            c2 = int.Parse(Console.ReadLine());
            if(c1!=r2)
                Console.WriteLine("Matrix multiplication cannot be performed");
            else
            {
                int[,] a = new int[r1,c1];
                int[,] b = new int[r2, c2];
                input(a);
                input(b);
                int[,] c = new int[r1, c2];
                for(int i=0;i<r1;i++)
                {                    
                    for (int j=0;j<c2;j++)
                    {
                        c[i, j] = 0;
                        for (int k=0;k<c1;k++)
                        {
                            c[i, j] += a[i, k] * b[k, j];
                        }
                    }
                }
                output(a);
                output(b);
                output(c);
            }
        }
    }
}
