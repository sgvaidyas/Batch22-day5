﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Jagged1
    {
        static void Main(string[] args)
        {
            int[][] a = new int[3][];

            a[0] = new int[2];
            a[1] = new int[3];
            a[2] = new int[1];

            Console.WriteLine("No of rows = "+a.GetLength(0));
            Console.WriteLine("No of columns in 1 st row = " + a[0].Length);
            Console.WriteLine("No of columns in 2 st row = " + a[1].Length);
            Console.WriteLine("No of columns in 3 st row = " + a[2].Length);
        }
    }
}
