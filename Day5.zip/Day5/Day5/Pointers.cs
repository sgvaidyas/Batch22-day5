﻿using System;

namespace Day5
{
    class Pointers
    {
        static unsafe void swap(int* a,int* b)
        {
            int temp;
            temp = *a;
            *a = *b;
            *b = temp;
        }
        static unsafe void Main(string[] args)
        {
            int a = 10, b = 20;
            swap(&a,&b);
            Console.WriteLine("A = " + a + " B = " +b);
        }
    }
}
