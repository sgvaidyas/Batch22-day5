﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Array1
    {
        static void Main(string[] args)
        {
            int[] a = new int[5];
            Console.WriteLine("Enter 5  elements");
            for (int i = 0; i < 5; i++)
                a[i] = int.Parse(Console.ReadLine());

            Array.Sort(a);
            Console.WriteLine("Sorted array a ");
            for (int i = 0; i < 5; i++)
                Console.WriteLine(a[i]);

            int[] b = new int[a.Length];
            Array.Copy(a, b, a.Length);
            Console.WriteLine("Array b ");
            for (int i = 0; i < 5; i++)
                Console.WriteLine(b[i]);
            Array.Reverse(b);
            Console.WriteLine("Reversed Array b ");
            for (int i = 0; i < 5; i++)
                Console.WriteLine(b[i]);

        }
    }
}
