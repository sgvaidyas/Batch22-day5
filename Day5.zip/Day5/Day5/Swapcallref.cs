﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Swapcallref
    {
        static void swap(int a,int b)
        {
            int temp;
            temp = a;
            a = b;
            b = temp;
            Console.WriteLine("inside swap The value of a ={0} and b = {1}",a,b);
        }
        static void swapref(ref int a, ref int b)
        {
            int temp;
            temp = a;
            a = b;
            b = temp;
            Console.WriteLine("inside swap The value of a ={0} and b = {1}", a, b);
        }
        static void Main(string[] args)
        {
            int a=10, b=20;
            Console.WriteLine("before swap The value of a ={0} and b = {1}", a, b);
            swap(a, b);
            Console.WriteLine("after swap The value of a ={0} and b = {1}", a, b);
            swapref(ref a, ref b);
            Console.WriteLine("after ref swap  The value of a ={0} and b = {1}", a, b);

        }
    }
}
