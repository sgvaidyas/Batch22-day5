﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class CallByval
    {
        static void passbyval(int x)
        {
            x = x + 60;
            Console.WriteLine("In Pass by val x = "+x);
        }
        static void passbyref(ref int x)
        {
            x = x + 60;
            Console.WriteLine("In Pass by Ref x = " + x);
        }

        static void Main(string[] args)
        {
            int x = 100;
            Console.WriteLine("X = "+x);
            passbyval(x);
            Console.WriteLine("After pass by val X = " + x);
            passbyref(ref x);
            Console.WriteLine("After pass by Ref X = " + x);
        }
    }
}
