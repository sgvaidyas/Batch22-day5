﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class NumberRepeats
    {
        static void Main(string[] args)
        {
            int[] a = { 11, 2, 33, 11, 2, 3, 2, 3, 6 };
            int n = a.Length;
            int cnt;
            for(int i = 0;i<n;i++)
            {
                cnt = 0;
                for(int j=0;j<n;j++)
                {
                    if (a[i] == a[j])
                        cnt++;
                }
                if(cnt>1)
                    Console.WriteLine(a[i] + " = " +cnt);
            }
        }
    }
}
