﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    class Jagged2
    {
        static void Main(string[] args)
        {
            int rows;

            Console.WriteLine("Enter the number of rows = ");
            rows = int.Parse(Console.ReadLine());

            int[][] a = new int[rows][];

            Console.WriteLine("Enter the elements = ");
            for(int i=0;i<rows;i++)
            {
                Console.WriteLine("Enter the num of cols ");
                int cols = int.Parse(Console.ReadLine());
                a[i] = new int[cols];
                Console.WriteLine("Enter the elements of row = "+i);
                for(int j=0;j<cols;j++)
                {
                    a[i][j] = int.Parse(Console.ReadLine());
                }
            }
            int sum;
            Console.WriteLine("Array elements are  = ");
            for(int i=0;i<rows;i++)
            {
                sum = 0;
                for(int j=0;j<a[i].Length;j++)
                {
                    Console.Write(a[i][j] + "\t");
                    sum += a[i][j];
                }
                Console.WriteLine( "="+ sum);
            }
        }
    }
}
